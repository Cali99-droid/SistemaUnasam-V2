<label for="passwordActual">
    Contraseña Actual
</label>
<input type="password" class="form-control" id="passwordActual" name="pass" />

<label for="passwordNuevo">
    Nueva Contraseña
</label>
<input type="password" class="form-control" id="passwordNuevo" name="npass" />




<input type="reset" class="btn-asignar" value="Cancelar">
<button class="btn-asignar">
    Aceptar
</button>
</input>