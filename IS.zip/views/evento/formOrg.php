<label for="nombre_org">Organizador</label>
<input type="text" name="nombre_org" id="nombre_org" required>
<label for="contacto">Numero Contacto</label>
<input type="tel" name="contacto" id="contacto" required>

<input type="hidden" name="idOrganizador" value='' id="idOrganizador">
<button class="" type="button" onclick="crearOrganizador()">Aceptar</button>