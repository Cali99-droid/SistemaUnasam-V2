<body id="cuerp">
    <div class="main-container">
        <div class="img-container container-item">
            <img src="/../build/img/105102.jpg" style="height: 450px; width: 650px;">

        </div>

        <div class="text-container container-item">
            <div class="code">404</div>
            <div class="msg"> La página que vio parece haberse perdido o no existe.. </div>
            <a class="action" href="/">
                <div> Regrese a la página de inicio para ver más contenido. </div>
            </a>
        </div>
    </div>
</body>