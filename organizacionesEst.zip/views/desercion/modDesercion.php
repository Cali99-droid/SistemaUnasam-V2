
       

            <label for="nombre">Causa de la desercion</label>
            <input type="text" name="desercion[nombre]" id="nombre" placeholder="Ingrese causa de deserción" autocomplete="off">

            <input id="idDesercion" type="hidden" value="">
            <button type="button" onclick="crearItemDesercion()">Aceptar</button>

       

    