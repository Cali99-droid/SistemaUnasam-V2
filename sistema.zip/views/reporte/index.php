<h1>Reportes</h1>
<div class="contenido-grupos">
    <div class="grupo">
        <a href="reportes/reporte1.php" target="_blank">
            <img src="https://conceptodefinicion.de/wp-content/uploads/2019/05/Tendencia-1.jpg" alt="Avatar" class="grupo-imagen">
            <div class="container">
                <h4> Reporte de tendecia de participantes por Escuela </h4>
                <p> Lista a los alumnos que parcticiparon por escuelas </p>
            </div>

        </a>

    </div>

    <div class="grupo">
        <a href="reportes/reporte2.php" target="_blank">
        <img src="https://www.ipanemacomunicacion.com/hubfs/Tendencias%20marketing%20b2b%202020.png" alt="Avatar" class="grupo-imagen">
            <div class="container">
                <h4> Reporte de tendecia de participantes por Grupos </h4>
                <p> Lista a los alumnos que parcticiparon por Grupos </p>
            </div>
        </a>

    </div>

    <div class="grupo">
    <a href="reportes/reporte3.php" target="_blank">
    <img src="https://blog.contpaqi.com/hubfs/Webpage2020/blog/blog-head-tendfisc.png" alt="Avatar" class="grupo-imagen">

        
            <div class="container">
                <h4>Reporte de tendecia de estudiantes por Escuelas</h4>
            </div>
        </a>

    </div>
<!--
    <div class="grupo">
    <a href="reportes/reporte4.php" target="_blank">
    <img src="https://media.istockphoto.com/vectors/isometric-business-to-business-marketing-b2b-solution-business-two-vector-id1271016756?k=20&m=1271016756&s=170667a&w=0&h=EikHJiay-J1NDSVHm-0zgEELq-7jCzDSMl1x4oEkd20=" alt="Avatar" class="grupo-imagen">
        
            <div class="container">
                <h4> Reporte de  </h4>
            </div>
        </a>
    </div> -->

    <div class="grupo">
        <a href="reportes/reporte5.php" target="_blank">
        <img src="https://www.aerocivil.gov.co/atencion/participacion/PublishingImages/nuestro-equipo-de-trabajo/equipo-trabajo%20copia.png" alt="Avatar" class="grupo-imagen">
            <div class="container">
                <h4>Reporte de Alumnos que no pertenecen a ningún grupo</h4>
            </div>
        </a>
    </div>

    <div class="grupo">
        <a href="reportes/reporte6.php" target="_blank">
        <img src="https://www.aerocivil.gov.co/atencion/participacion/PublishingImages/nuestro-equipo-de-trabajo/equipo-trabajo%20copia.png" alt="Avatar" class="grupo-imagen">
            <div class="container">
                <h4>Reporte de Alumnos que tuvieron una deserción por facultades</h4>
            </div>
        </a>
    </div>


</div>